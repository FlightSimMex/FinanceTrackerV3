package org.flightsimmex.financetracker3;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

class FooterEvent extends PdfPageEventHelper {
    final private Font footerFont = new Font(Font.FontFamily.HELVETICA, 10);
    
    @Override
    public void onEndPage(PdfWriter writer, Document document) {
        PdfContentByte canvas = writer.getDirectContent();
        Phrase footer = new Phrase("Generated on: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()), footerFont);
        
        ColumnText.showTextAligned(canvas, Element.ALIGN_RIGHT, footer, 
            document.right() - 40, document.bottom() - 20, 0);

    }
}
