package org.flightsimmex.financetracker3;


/**
 * Class Name: InvalidEntryException
 * Credit: Pablo Bandera Lopez
 * Created: 03/24/2025
 * Modified: 
 * 
 * Description: Exception class for invalid entries
 * 
 * Attributes:
 * 
 * Methods:
 * + <<constructor>>InvalidEntyrException(String)
 * 
 * 
 */
public class InvalidEntryException extends Exception {
    public InvalidEntryException(String msg){
        super(msg);
    }
    
}
