package org.flightsimmex.financetracker3;

import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Scanner;

import javax.swing.JOptionPane;
import javax.swing.JTable;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;






/**
 * Class Name: FileManager
 * Credit: Pablo Bandera Lopez
 * Created: 03/31/2025
 * Modified: 04/01/2025
 * 
 * Description: Class deals with File I/O. Has three sets of methds:
 * FILE PATH & DIRECTORY: Used to construct strings pointing to the files needed to read and write and create and delete files. Uses Calendar to determine the current Month and Year.
 * PRINTING METHODS: Use PrintWriter to print out to a file based on the path given.
 * READING METHODS: Use Scanner to read information from the input document.
 * 
 * Attributes:
 * - month: String
 * - year: String
 * - C: Calendar
 * 
 * Methods:
 * + <<constructor>>FileManager()
 * + getCurrentMonth(): String
 * + getCurrentYear(): String
 * + getFilePath(String, String): String
 * + getDirectoryPath(String): String
 * + filePathExists(String, String): boolean
 * + directoryExists(String): boolean
 * + makeDir(String): void
 * + makeFile(String): void
 * + rmvFile(String): void
 * + updateFile(Entries): void
 * + readEntries(String): Entries
 * + entryStringToEntry(String): Entry
 * + getNumberOfEntries(String): int
 * 
 */
public class FileManager {
    
    /*Attributes*/
    private String month, year;
    final private static Calendar C = Calendar.getInstance();

    @SuppressWarnings("OverridableMethodCallInConstructor")
    public FileManager()//Constructor
    {   
        
        String m = this.getCurrentMonth();
        String y = this.getCurrentYear();
        if(m != null && !m.isEmpty()){this.month = m;}
        if(y != null && !y.isEmpty()) {this.year  = y;}
        
    }


    /* FILE PATH & DIRECTORY METHODS */
    public String getCurrentMonth()
    {
        int monthInt = C.get(Calendar.MONTH);
        DateFormatSymbols symbols = new DateFormatSymbols();
        String [] months = symbols.getMonths();
        return months[monthInt];
    }

    public String getCurrentYear()
    {
        int yearInt = C.get(Calendar.YEAR);
        return String.valueOf(yearInt);
    }

    public String getFilePath(String m, String y)
    {
        String path = "./Files/"+y+"/"+m+".txt";
        return path;
    }

    public String getFilePathPDF(String m, String y)
    {
        String path = "./Files/Exports/"+y+"/"+m+".pdf";
        return path;
    }

    public String getDirectoryPath(String y)
    {
        String path = "./Files/"+y;
        return path;
    }
    
    public boolean filePathExists(String m, String y) {return Files.exists(Paths.get(getFilePath(m, y)));}
    public boolean directoryExists(String y) {return Files.exists(Paths.get(getDirectoryPath(y)));}

    public void makeDir(String path)
    {
        File f = new File(path);
        f.mkdirs();
    }

    public void makeFile(String path)
    {
        File f = new File(path);
        try{f.createNewFile();}
        catch(IOException e){JOptionPane.showMessageDialog(null, e.toString(), "Error", JOptionPane.ERROR_MESSAGE);}
    }

    public void rmvFile(String path)
    {
        File f = new File(path);
        try{f.delete();}catch(Exception e){}
    }



    /* PRINTING METHODS */
    public void updateFile(Entries entries)//Updates the file with the current entries
    {
    
        try (PrintWriter pw = new PrintWriter(new File(getFilePath(month, year)))) {
            for(Entry e : entries.getEntries())
            {
                pw.println(e.toString());
            }
        } catch (FileNotFoundException e) 
        {
            JOptionPane.showMessageDialog(null, e.toString(), "Error: File Not Found", JOptionPane.ERROR_MESSAGE);
        }
        
    }


    /* READING METHODS */
    public Entries readEntries(String path)//Loads the file into the entries
    {
        try (Scanner s = new Scanner(new File(path));){
            String entryString;
            Entry e;
            Entries entries = new Entries();
            
            while(s.hasNextLine())
            {
                entryString = s.nextLine();
                try{
                    e = entryStringToEntry(entryString);
                    entries.addEntryNoUpdate(e);
                    
                }catch(FileFormatException ex){}
            }
            s.close();
            return entries;
        } catch (FileNotFoundException ex) 
        {
            JOptionPane.showMessageDialog(null, ex.toString(), "Error: File Not Found", JOptionPane.ERROR_MESSAGE);
        }
        return null;
        
    }

    public Entry entryStringToEntry(String s) throws FileFormatException
    {

        String [] tokens = s.split(",");
        if(tokens.length < 10){throw new FileFormatException("Error Reading File");}
        try
        {
            Entry e  = new Entry(Integer.parseInt(tokens[0]));
            e.setAmount(Double.parseDouble(tokens[1]));
            e.setType(Integer.parseInt(tokens[2]));
            e.setCategory(Integer.parseInt(tokens[3]));
            int i = Integer.parseInt(tokens[4]);
            if(i > 0){e.setSubcategory(i);}
            i = Integer.parseInt(tokens[5]);
            if(i > 0){e.setSubcategory2(i);}
            i = Integer.parseInt(tokens[6]);
            if(i > 0){e.setSubcategory3(i);}
            i = Integer.parseInt(tokens[7]);
            if(i > 0){e.setSubcategory4(i);}
            e.setAccount(Integer.parseInt(tokens[8]));
            e.setComment(tokens[9]);
            return e;

        }catch(InvalidEntryException e){}
        return null;
    }

    public int getNumberOfEntries(String path)//Returns the number of entries in the file
    {  
        try (Scanner s = new Scanner(new File(path));){
            int counter = 0;
            while(s.hasNextLine()){
                counter ++;
                s.nextLine();
            }
            s.close();
            return counter;
        }catch (FileNotFoundException ex){}
        return 0;
    }

    public void printTables(JTable table_e, JTable table_t, String month) {
        try {
            // Define file path
            String filePath = getFilePathPDF(month, year);
            File pdfFile = new File(filePath);
            pdfFile.getParentFile().mkdirs(); // Create parent directories if they don't exist
    
            // Create document in landscape mode
            Document doc = new Document(PageSize.A4.rotate());
    
            PdfWriter w = PdfWriter.getInstance(doc, new FileOutputStream(filePath));
            w.setPageEvent(new FooterEvent()); // Add footer event
            doc.open();

            doc.add(new Paragraph("\n\n\n\n\n"));
            Image image = Image.getInstance("./Files/src/Heading.jpg"); // Ensure the image path is correct
            image.scaleToFit(400, 200); // Resize to fit the page
            image.setAlignment(Image.ALIGN_CENTER); // Center the image
            doc.add(image);
            doc.add(new Paragraph("\n\n")); // Extra spacing after the image


            // Define title font
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
            Paragraph title = new Paragraph("Monthly Report: " + month + " "+year, titleFont);
            title.setAlignment(Element.ALIGN_CENTER); // Center the title
            doc.add(title);

            // Add some spacing
            doc.newPage();

    
            // Define bold font for headers
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
            
            // Define row colors
            BaseColor headerColor = BaseColor.LIGHT_GRAY;
            BaseColor alternateRowColor = new BaseColor(230, 230, 230); // Slightly lighter gray
    
            // Create and populate entries table (borderless)
            PdfPTable entries_table = new PdfPTable(table_e.getColumnCount());
            entries_table.setWidthPercentage(100);
            entries_table.setHeaderRows(1); // Ensures header repeats on each new page
            
            // First row (header) with bold font and background color
            for (int i = 0; i < table_e.getColumnCount(); i++) {
                PdfPCell headerCell = new PdfPCell(new Paragraph(table_e.getColumnName(i), headerFont));
                headerCell.setBackgroundColor(headerColor); // Header background color
                headerCell.setBorder(Rectangle.NO_BORDER); // Remove border
                entries_table.addCell(headerCell);
            }
    
            // Remaining rows with alternate row coloring
            for (int rows = 0; rows < table_e.getRowCount(); rows++) {
                for (int cols = 0; cols < table_e.getColumnCount(); cols++) {
                    PdfPCell cell = new PdfPCell(new Paragraph(table_e.getModel().getValueAt(rows, cols).toString()));
                    cell.setBorder(Rectangle.NO_BORDER); // Remove border
    
                    // Apply alternate row coloring
                    if (rows % 2 == 0) {
                        cell.setBackgroundColor(alternateRowColor);
                    }
    
                    entries_table.addCell(cell);
                }
            }

            // Calculate column widths dynamically
            float[] columnWidths = new float[table_e.getColumnCount()];
            for (int col = 0; col < table_e.getColumnCount(); col++) {
                int maxWidth = table_e.getColumnName(col).length(); // Start with header length
                for (int row = 0; row < table_e.getRowCount(); row++) {
                    int contentLength = table_e.getModel().getValueAt(row, col).toString().length();
                    maxWidth = Math.max(maxWidth, contentLength);
                }
                columnWidths[col] = maxWidth + 5; // Add padding
            }

            // Apply the calculated widths
            entries_table.setWidths(columnWidths);
    
            // Add first table
            doc.add(entries_table);
    
            // Insert Page Break
            doc.newPage();
    
            // Create and populate totals table (borderless)
            PdfPTable totals_table = new PdfPTable(table_t.getColumnCount());
            totals_table.setWidthPercentage(100);
            totals_table.setHeaderRows(1); // Ensures header repeats on each new page
    
            // First row (header) with bold font and background color
            for (int i = 0; i < table_t.getColumnCount(); i++) {
                PdfPCell headerCell = new PdfPCell(new Paragraph(table_t.getColumnName(i), headerFont));
                headerCell.setBackgroundColor(headerColor); // Header background color
                headerCell.setBorder(Rectangle.NO_BORDER); // Remove border
                totals_table.addCell(headerCell);
            }
    
            // Remaining rows with alternate row coloring
            for (int rows = 0; rows < table_t.getRowCount(); rows++) {
                for (int cols = 0; cols < table_t.getColumnCount(); cols++) {
                    PdfPCell cell = new PdfPCell(new Paragraph(table_t.getModel().getValueAt(rows, cols).toString()));
                    cell.setBorder(Rectangle.NO_BORDER); // Remove border
    
                    // Apply alternate row coloring
                    if (rows % 2 == 0) {
                        cell.setBackgroundColor(alternateRowColor);
                    }
    
                    totals_table.addCell(cell);
                }
            }
            
    
            // Add second table
            doc.add(totals_table);
    
            doc.close();
    
            JOptionPane.showMessageDialog(null, "Export Successful" + filePath, "Success", JOptionPane.INFORMATION_MESSAGE);
            
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(new File(filePath));
            }
            
        } catch (DocumentException | IOException e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

}//End of Class

   
